package arvoreBuscaBinaria;

public class No {
	public int valor;
	public No esquerda;
	public No direita;
	
	// CONSTRUTOR
	No(int valor) {
		this.valor = valor;
		this.esquerda = null;
		this.direita = null;
	}

}
